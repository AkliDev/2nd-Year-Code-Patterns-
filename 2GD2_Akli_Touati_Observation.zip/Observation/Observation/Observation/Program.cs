﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observation
{
    class Program
    {
        static void Main(string[] args)
        {
            Scene _Scene = new Scene();

            while (1 == 1)
            {
                _Scene.Update();
            }
        }

    }
}
