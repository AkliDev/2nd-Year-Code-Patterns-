﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observation
{
    class Stand : IState
    {

        public Stand()
        {

        }
        public void Enter()
        {

        }
        public void Update()
        {

        }
        public void Exit()
        {

        }
    }


    class Attack : IState
    {

        public Attack()
        {

        }
        public void Enter()
        {

        }
        public void Update()
        {

        }
        public void Exit()
        {

        }
    }

    class AmHit : IState
    {

        public AmHit()
        {

        }
        public void Enter()
        {

        }
        public void Update()
        {

        }
        public void Exit()
        {

        }
    }

}
