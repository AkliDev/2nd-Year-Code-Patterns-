Player 1 controls:
F1
F2

Player2 controls:
F7
F8